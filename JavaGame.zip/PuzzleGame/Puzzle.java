import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

  public class Puzzle extends JFrame 
   {
	   
   private JButton  b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
   private JLabel pointLabel;
   private JPanel panel;
    
   
  Puzzle()
  {
	  
      super("puzzle");
	  this.setSize(600,400);
	  this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  
	  panel=new JPanel();
      panel.setLayout(null);
	  
	pointLabel=new JLabel("point:");
    pointLabel.setBounds(0,0,50,70);
    panel.add(pointLabel);
    this.add(panel);
  
  
  b1=new JButton("1");
  b1.setBounds(40,50,50,40);
  b1.setBackground(Color.CYAN);
  panel.add(b1);
  
  b2=new JButton("2");
  b2.setBounds(100,50,50,40);
  b2.setBackground(Color.CYAN);
  panel.add(b2);
  
  b3=new JButton("3");
  b3.setBounds(10,100,50,40);
  b3.setBackground(Color.CYAN);
  panel.add(b3);
  
  b4=new JButton("4");
  b4.setBounds(80,100,50,40); 
  b4.setBackground(Color.CYAN);
  panel.add(b4);
  
   b5=new JButton("5");
   b5.setBounds(10,160,50,40);
   b5.setBackground(Color.BLUE);
   panel.add(b5);
  
   b6=new JButton("6");
   b6.setBounds(80,160,50,40);
   b6.setBackground(Color.BLUE);
   panel.add(b6);
   
   b7=new JButton("7");
   b7.setBounds(10,220,50,40);
   b7.setBackground(Color.BLUE);
   panel.add(b7);
   
   b8=new JButton("8");
   b8.setBounds(70,220,50,40);
   b8.setBackground(Color.BLUE);
   panel.add(b8);
  
   b9=new JButton("9");
   b9.setBounds(10,270,50,40);
   b9.setBackground(Color.BLUE);
   panel.add(b9);
  
   b10=new JButton("10");
   b10.setBounds(70,270,50,40);
   b10.setBackground(Color.BLUE);
   panel.add(b10);
   
  this.setVisible(true);
 
  
  
/*
b1.addActionListener(this);
b2.addActionListener(this);
b3.addActionListener(this);
b4.addActionListener(this);
b5.addActionListener(this);
b6.addActionListener(this);
b7.addActionListener(this);
b8.addActionListener(this);
b9.addActionListener(this);
b10.addActionListener(this);

*/






}
/*
    public void mouseEntered(MouseEvent me)
{
	if(me.getSource()==b1)
	{
		b1.setBackgroundColor(Color.WHITE);
		b1.setForegroundColor(Color.BLUE);
	}
	else if(me.getSource()==b2)
	{
		b2.setBackgroundColor(Color.WHITE);
		b2.setForegroundColor(Color.BLUE);
	}
	else
	{
		
	}
}
 public void mouseExited(MouseEvent me)
{ 
    if(me.getSource()==b1)
	{
		
	
	b1.setBackgroundColor(Color.RED);
	b1.setForegroundColor(Color.BLACK);
	}
	else if(me.getSource()==b2)
	{
		b2.setBackgroundColor(Color.YELLOW);
		b2.setForegroundColor(Color.BLACK);
	}
	else
	{
		
	}
}
*/
public static void main(String[]args)
{
	new Puzzle();
}




}


