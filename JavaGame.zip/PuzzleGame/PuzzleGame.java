import java.awt.;
import java.awt.event;
import java.util.Random;
import javax.swing.JOptionPane;
public class PuzzleGame extends JFrame implements ActonListener

{
	private JButton b1,b2,b3,b4,b5.b6,b7,b8,b9,b10;
	PuzzleGame()
	{
		super("PuzzleGame");
		b1.new Button("1");
		b1.setBounds(50,100,40,40);
		
		b2.new Button("2");
		b2.setBounds(100,100,40,40);
		
		b3.new Button("3");
		b3.setBounds(50,100,40,40);
		
		b4.new Button("4");
		b4.setBounds(150,100,40,40);
		
		b5.new Button("5");
		b5.setBounds(50,100,40,40);
		
		b6.new Button("6");
		b6.setBounds(150,150,40,40);
		
		b7.new Button("7");
		b7.setBounds(50,100,40,40);
		
		b8.new Button("8");
		b8.setBounds(50,200,40,40);
		
		b9.new Button("9");
		b9.setBounds(100,200,40,40);
		
		b10.new Button("10");
		b10.setBounds(150,200,40,40);
		
		b1.ActionListener(this);
		b2.ActionListener(this);
		b3.ActionListener(this);
		b4.ActionListener(this);
		b5.ActionListener(this);
	    b6.ActionListener(this);
		b7.ActionListener(this);
		b8.ActionListener(this);
		b9.ActionListener(this);
		b10.ActionListener(this);
		next.ActionListener(this);
		 add(b1);
		 add(b2);
		 add(b3); 
		 add(b4);
		 add(b5);
		 add(b6);
		 add(b7);
		 add(b8);
		 add(b9); 
         add(10);
		 next();
       setSize(400,400);  
       setLayout(null);  
       setVisible(true);  
		next.setBackgroundColor(Color.BLACK);
		next.setForegroundColor(Color.GREEN);
		
		public void ActionPerformed(ActionEvent ae)
		if(e.getSource==next)
		{
			String s=b4.getLabel();
			b4.setLabel(b9.getLabel());
			b9.setLabel();
		}
		
		
		
		
		
	}
	
	
	
	
}