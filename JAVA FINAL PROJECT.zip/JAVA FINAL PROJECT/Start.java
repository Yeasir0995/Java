import java.lang.*;

public class Start
{
	static public void main(String args[])
	{
		Home hg = new Home();
		hg.setVisible(true);
		
	}
}
